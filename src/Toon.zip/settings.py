#Settings file for the Appie skill
username = "Your Eneco Username"
password = "Your Eneco Username"
applicationID = "amzn1.ask.skill.xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"